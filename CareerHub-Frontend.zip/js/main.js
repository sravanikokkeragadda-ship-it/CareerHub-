const themeBtn=document.getElementById('themeBtn');
if(localStorage.getItem('theme')==='dark')document.body.classList.add('dark');
if(themeBtn)themeBtn.addEventListener('click',()=>{document.body.classList.toggle('dark');localStorage.setItem('theme',document.body.classList.contains('dark')?'dark':'light');themeBtn.textContent=document.body.classList.contains('dark')?'☀️':'🌙'});
const menuBtn=document.getElementById('menuBtn'),nav=document.getElementById('nav');
if(menuBtn)menuBtn.onclick=()=>nav.classList.toggle('open');
