# CareerHub 🚀

CareerHub is a responsive frontend job-search platform built with HTML, CSS and vanilla JavaScript.

## Features
- Responsive landing page
- Job search and filtering
- Job details page
- Apply workflow
- Application tracking
- Profile management
- Login/register UI
- Save jobs with LocalStorage
- Dark mode
- Mobile navigation

## Tech Stack
HTML5 • CSS3 • JavaScript • LocalStorage

## Run locally
Open `index.html` in your browser, or use VS Code Live Server.

## GitHub
Create a repository named `careerhub-frontend`, upload all project files, and enable GitHub Pages from Settings → Pages → Deploy from branch → main → /(root).

## Resume
**CareerHub – Job Search & Career Management Platform**  
Developed a responsive job-search platform with search/filtering, job details, application tracking, profile management, LocalStorage persistence, dark mode and responsive UI using HTML, CSS and JavaScript.
